import acm.program.ConsoleProgram;

public class DeleteCharacteresFromString extends ConsoleProgram {
	public void run() {

		String string1 = "This is a test";
		String string2 = "Summer is here!";

		String string4 = "---0---";

		println(removeAllOccurrences(string1, 't'));
		println(removeAllOccurrences(string2, 'e'));
		println(removeAllOccurrences(string4, '-'));

	}

	private String removeAllOccurrences(String str, char ch) {

		String newStr = "";

		int lengthOfString = str.length();

		for (int i = 0; i < lengthOfString; i++) {
			int a = i;
			char b = Integer.toString(a).charAt(0);

			if (str.charAt(i) == ch) {
				newStr = newStr.replace(b, b);
				

			} else {
				newStr = newStr + str.charAt(i);

			}

		}

		return newStr;
	}
}
