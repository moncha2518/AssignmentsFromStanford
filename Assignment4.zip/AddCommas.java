import acm.program.ConsoleProgram;

public class AddCommas extends ConsoleProgram {

	public void run() {

		while (true) {
			String digits = readLine("Enter a numeric string: ");
			println(addCommasToNumericString(digits));
		}
	}

	private String addCommasToNumericString(String digits) {
		int lengthOfString = digits.length();
		String updateString = " ";

		int counter = 0;

		for (int i = lengthOfString - 1; i >= 0; i--) {

			updateString = digits.charAt(i) + updateString;
			if (counter % 3 == 2) {
				updateString = (",") + updateString;
			}
			counter++;
		}
		if (lengthOfString % 3 == 0) {
			return updateString.substring(1);
		} else {
			return updateString;
		}
	}
}
