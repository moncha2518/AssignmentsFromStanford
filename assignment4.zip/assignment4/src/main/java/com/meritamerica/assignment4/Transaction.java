package com.meritamerica.assignment4;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public abstract class Transaction {
	
	private BankAccount sourceAccount;
	private BankAccount targetAccount;
	
	private double amount;
	private Date transactionDate;
	private String rejectionReason;
	private boolean processedByFraudTeam;
	
	
	public static double fraudAmontLimit = 1000;

	
	public BankAccount getSourceAccount() {
		return this.sourceAccount;
	}

	public void setSourceAccount(BankAccount sourceAccount) {
		this.sourceAccount = sourceAccount;
	}
	
	public BankAccount getTargetAccount() {
		return this.targetAccount;
	}

	public void setTargetAccount(BankAccount targetAccount) {
		this.targetAccount = targetAccount;
	}

	public double getAmount() {
		return this.amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(Date date) {
		this.transactionDate = date;
	}
	
	public String getRejectionReason() {
		return this.rejectionReason;
	}

	public void setRejectionReason(String reason) {
		this.rejectionReason = reason;

	}
	
	public boolean isProcessedByFraudTeam(){
		return this.processedByFraudTeam;
	}
	
	public void setProcessedByFraudTeam(boolean isProcessed){
		this.processedByFraudTeam = isProcessed;
	}
	
	public String writeToString() {

		String message = "Transaction["
			+"| From: "+getSourceAccount().getAccountNo()
			+"| To: "+getTargetAccount().getAccountNo()
			+"| Amount: "+this.getAmount()
			+"| Date: "+this.getTransactionDate();
		return message;
	}

	public abstract void process() 
	throws NegativeAmountException, ExceedsAvailableBalanceException,ExceedsFraudSuspicionLimitException;
	
	
	/**
	 * Assignment#4
	 * @sample 
	 * -1,2,15000,01/02/2020 => Initial deposit of $15,000 on 1/2/2020 into account#2
	 * -1,2,-2000,01/03/2020 =>	Withdrawal of $2,000 on 1/3/2020 from account#2
	 * 1,3,100,01/03/2020 => Transfer of $100 from account 1 on 1/3/2020 into account#3
	 */
	public static Transaction readFromString(String transactionDataString){
		System.out.println(transactionDataString);
		Transaction transaction = null; 
		
		int fromAccountNo = 0;
		int toAccountNo = 0;
		double amount = 0;
		Date transactiondate = new Date();
		
		try {
			StringTokenizer st1 = new StringTokenizer(transactionDataString , ",");
			int index = 0;
			while (st1.hasMoreTokens()) {
				switch (index) {
				case 0:
					fromAccountNo = Integer.parseInt(st1.nextToken());
					break;
				case 1:
					toAccountNo = Integer.parseInt(st1.nextToken());
					break;
				case 2:
					amount = Double.parseDouble(st1.nextToken());
					break;
				case 3:
					transactiondate = new SimpleDateFormat("MM/dd/yyyy").parse(st1.nextToken());
					break;
				default:
					break;
				}
				index++;
			}
			
			if (fromAccountNo<0){
				//deposit
				if (amount>0){
					BankAccount bankAccount = MeritBank.getBankAccount(toAccountNo);
					transaction = new DepositTransaction(bankAccount, amount);
					transaction.setTransactionDate(transactiondate);
				} 
				//withdraw
				else{
					BankAccount bankAccount = MeritBank.getBankAccount(toAccountNo);
					transaction = new WithdrawTransaction(bankAccount, amount);
					transaction.setTransactionDate(transactiondate);
				}
			}
			//transfer
			else{
				BankAccount fromAccount = MeritBank.getBankAccount(fromAccountNo);
				BankAccount toAccount = MeritBank.getBankAccount(toAccountNo);
				transaction = new TransferTransaction(fromAccount, toAccount, amount);
				transaction.setTransactionDate(transactiondate);
			}
			
		}  
		catch (ParseException pex) {
			pex.printStackTrace();
			System.err.println("ParseException: "+pex.getMessage());
		} catch (NumberFormatException nex) {
			nex.printStackTrace();
			System.err.println("NumberFormatExcepton is Handled!, "+nex.getMessage());
		}
		return transaction; 
	}
	
}

