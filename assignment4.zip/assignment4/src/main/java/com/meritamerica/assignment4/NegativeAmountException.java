package com.meritamerica.assignment4;

public class NegativeAmountException extends Exception{

	// to set serialVersionUID=1L because the conditions need to be checked always pass( the value is always the same) and it is ok to
	//subtle the class a class version incompatibiltiy problems.
	private static final long serialVersionUID = 1L;

	public NegativeAmountException (String message)
	{
		System.out.println (message);
	}
}
