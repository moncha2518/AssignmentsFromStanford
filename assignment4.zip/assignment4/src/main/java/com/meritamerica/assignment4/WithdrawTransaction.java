package com.meritamerica.assignment4;

public class WithdrawTransaction extends Transaction{
	
	public WithdrawTransaction(BankAccount bankAccount, double amount){
		setSourceAccount(bankAccount);
		setTargetAccount(bankAccount);
		setAmount(amount);
	}
	
	public void process() throws NegativeAmountException
	, ExceedsAvailableBalanceException, ExceedsFraudSuspicionLimitException{
	
		if (getAmount() > getSourceAccount().getBalance()){
			throw new ExceedsAvailableBalanceException("Transfer amount should be less than balance in source account");
		}
		if (getAmount() > fraudAmontLimit){
			Transaction withdrawTrans = new WithdrawTransaction(getSourceAccount(), getAmount());
			MeritBank.fraudQueue.addTransaction(withdrawTrans);
			throw new ExceedsFraudSuspicionLimitException("Transfer amount exceeding $1,000 must be reviewed by the fraud team");
		}
		
		getSourceAccount().withdraw(getAmount());
	}
}

