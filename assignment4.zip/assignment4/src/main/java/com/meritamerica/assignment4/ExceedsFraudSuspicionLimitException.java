package com.meritamerica.assignment4;

public class ExceedsFraudSuspicionLimitException  extends Exception{

	private static final long serialVersionUID = 1L;
	public double amount;

	public ExceedsFraudSuspicionLimitException ()
	{
		super();
	}
	
	public ExceedsFraudSuspicionLimitException (String message)
	{
		super(message);
	}
	
	public ExceedsFraudSuspicionLimitException (String message, double amount)
	{
		super(message+" ("+amount+")");
	}

}

