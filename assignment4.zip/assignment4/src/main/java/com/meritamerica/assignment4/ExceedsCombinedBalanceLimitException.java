
package com.meritamerica.assignment4;

public class ExceedsCombinedBalanceLimitException extends Exception{

	private static final long serialVersionUID = 1L;
	public double amount;

	public ExceedsCombinedBalanceLimitException ()
	{
		super();
	}
	
	public ExceedsCombinedBalanceLimitException (String message)
	{
		super(message);
	}
	
	public ExceedsCombinedBalanceLimitException (String message, double amount)
	{
		super(message+" ("+amount+")");
	}

}
