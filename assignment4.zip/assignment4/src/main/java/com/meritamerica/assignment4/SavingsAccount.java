package com.meritamerica.assignment4;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class SavingsAccount extends BankAccount{

	public SavingsAccount(double balance){
		super(balance);
	}
	
	public SavingsAccount(double balance, double interestRate){
		super(balance, interestRate);
	}

	public SavingsAccount(long accountNo, double balance, double interestRate){
		super(accountNo, balance, interestRate);
	}
	
	public SavingsAccount(long accountNo, double balance, double interestRate 
	, Date accountOpenedOn) {
		super(accountNo, balance, interestRate, accountOpenedOn);
	}
	
	public static SavingsAccount readFromString(String accountData) {
		SavingsAccount bankAccount =  null;
		System.out.println(accountData);
		
		long accountno = 0;
		double balance = 0;
		double interest = 0;
		Date accountdate = new Date();
		
		try {
			StringTokenizer st1 = new StringTokenizer(accountData , ",");
			int index = 0;
			while (st1.hasMoreTokens()) {
				switch (index) {
				case 0:
					accountno = Long.parseLong(st1.nextToken());
					break;
				case 1:
					balance = Double.parseDouble(st1.nextToken());
					break;
				case 2:
					interest = Double.parseDouble(st1.nextToken());
					break;
				case 3:
					accountdate = new SimpleDateFormat("MM/dd/yyyy").parse(st1.nextToken());
					break;
				default:
					break;
				}
				index++;
			}
			bankAccount = new SavingsAccount(accountno, balance, interest, accountdate);
		}  
		catch (ParseException pex) {
			System.err.println("ParseException: "+pex.getMessage());
		} catch (NumberFormatException nex) {
			System.err.println("NumberFormatExcepton is Handled!, "+nex.getMessage());
		}
		return bankAccount; 
	}
	
	public String writetoString() {
		return "SavingAccount: " + this.getAccountNo() 
		+ "|" + MeritBank.numberformat.format(this.getBalance()) 
		+ "|" + MeritBank.numberformat.format(this.getInterestRate()) 
		+ "|" + this.getOpenedOn();
	}
}
