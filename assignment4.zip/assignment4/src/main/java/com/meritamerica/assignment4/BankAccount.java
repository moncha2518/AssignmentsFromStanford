
package com.meritamerica.assignment4;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;

public abstract class BankAccount {

	private long accountNo;
	private double balance;
	private double interestRate;
	private Date accountOpenedOn;
	
	/**
	 * Assignment#4
	 */
	private ArrayList<Transaction> transactions =new ArrayList<Transaction>();
	

	public BankAccount(double balance, double interestRate) {
		this.balance = balance;
		this.interestRate = interestRate;
	}
	
	public BankAccount(double balance, double interestRate, Date accountOpenedOn) {
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountOpenedOn = accountOpenedOn;
	}

	public BankAccount(long accountNo, double balance, double interestRate
	, Date accountOpenedOn) {
		this.accountNo = accountNo;
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountOpenedOn = accountOpenedOn;
	}
	
	public BankAccount(long accountNo, double balance, double interestRate) {
		this.accountNo = accountNo;
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public BankAccount(double balance) {
		this.balance = balance;
		this.interestRate = 0;
	}

	public long getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return this.balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterestRate() {
		return this.interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public boolean withdraw(double amount) {
		if (amount >= 0 && amount <= this.balance) {
			this.balance -= amount;
			return true;
		} else {
			return false;
		}
	}

	public boolean deposit(double amount) {
		if (amount >= 0) {
			this.balance += amount;
			return true;
		} else {
			return false;
		}
	}

	public double futureValue(int years) {
		double futureBalanace = this.balance * Math.pow((1 + this.interestRate), years);
		return futureBalanace;
	}
	
	public Date getOpenedOn() {
		return this.accountOpenedOn;
	}
	
	public void setOpenedOn(Date accountOpenedOn) {
		this.accountOpenedOn = accountOpenedOn;
	}

	//ParseException , if the date string could not be parsed
	
	public String writetoString() {
		return "BankAccount: " + this.getAccountNo() 
		+ "|" + MeritBank.numberformat.format(this.getBalance()) 
		+ "|" + MeritBank.numberformat.format(this.getInterestRate()) 
		+ "|" + this.getOpenedOn();
	}
	
	
	/**
	 * Assignment#4
	 */
	public void addTransaction(Transaction transaction){
		this.transactions.add(transaction);
	}
	public List<Transaction> getTransactions(){
		return this.transactions;
	}

}
