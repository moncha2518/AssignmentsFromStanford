
package com.meritamerica.assignment4;

import java.util.ArrayList;

public class FraudQueue {
	
	private ArrayList<Transaction> transactions =new ArrayList<Transaction>();
	
	public FraudQueue(){
	}
	
	public void addTransaction(Transaction transaction){
		this.transactions.add(transaction);
	}
	
	public Transaction getTransaction(){
		Transaction transaction = null;
		if (this.transactions.size()>0){
			transaction = this.transactions.get(0);
			this.transactions.remove(0);
		}
		return transaction;
	}

}
