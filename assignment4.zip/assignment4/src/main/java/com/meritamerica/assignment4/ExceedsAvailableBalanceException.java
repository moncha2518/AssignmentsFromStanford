package com.meritamerica.assignment4;

public class ExceedsAvailableBalanceException extends Exception{

	// to set serialVersionUID=1L because the conditions need to be checked always pass( the value is always the same) and it is ok to
	//subtle the class a class version incompatibiltiy problems.
	private static final long serialVersionUID = 1L;
	public double amount;

	// to use super(), in case of a custom exception , to use super() to initialize the exception's error message by passing the message
	// into the base class constructor, the base class will take care of the work
	public ExceedsAvailableBalanceException ()
	{
		super();  
	}
	
	public ExceedsAvailableBalanceException (String message)
	{
		super(message);
	}
	
	public ExceedsAvailableBalanceException (String message, double amount)
	{
		super(message+" ("+amount+")");
	}
}

