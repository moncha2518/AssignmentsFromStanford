
package com.meritamerica.assignment4;

import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.lang.Comparable;
import java.lang.Double;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AccountHolder implements Comparable<AccountHolder> {
	private String firstName;
	private String middleName;
	private String lastName;
	private String ssn;
	private long accountNumber;
	

	private ArrayList<CheckingAccount> checkingAccounts;
	private ArrayList<SavingsAccount> savingsAccounts;
	private ArrayList<CDAccount> cdAccounts;

	public AccountHolder(String firstName, String middleName, String lastName, String ssn) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.ssn = ssn;

		checkingAccounts = new ArrayList<CheckingAccount>();
		savingsAccounts = new ArrayList<SavingsAccount>();
		cdAccounts = new ArrayList<CDAccount>();

	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSSN() {
		return this.ssn;
	}

	public void setSSN(String ssn) {
		this.ssn = ssn;
	}

	public String writetoString() {
		return "Name: " + this.accountNumber+"|"
			+ this.firstName + "|" + this.middleName + "|" + this.lastName 
			+ "|" + this.ssn+ "|" +MeritBank.numberformat.format(this.getCombinedBalance());
	}

	// -------------- checking account ------------
	public CheckingAccount addCheckingAccount(double openingBalance) 
		throws ExceedsCombinedBalanceLimitException{

		double totalBalance = getCombinedBalance();

		if ((openingBalance + totalBalance) > MeritBank.accountLimit) {
			//assignment#4 - throw exception
			throw new ExceedsCombinedBalanceLimitException("The combined balance limit is exceeded");
		}

		long newAccountNumber = MeritBank.getNextAccountNumber();

		double interest = 0.0001;

		CheckingAccount account = new CheckingAccount(newAccountNumber, openingBalance, interest);
		
		//assignment#4 - add transaction
		Transaction transaction = new DepositTransaction(account, openingBalance);
		account.addTransaction(transaction);
		
		this.checkingAccounts.add(account);


		return account;

	}

	public CheckingAccount addCheckingAccount(CheckingAccount checkingAccount) 
		throws ExceedsCombinedBalanceLimitException{
		double totalBalance = getCombinedBalance();
		if ((checkingAccount.getBalance() + totalBalance) > MeritBank.accountLimit) {
			//assignment#4 - throw exception
			throw new ExceedsCombinedBalanceLimitException("The combined balance limit is exceeded");
		}
		
		//assignment#4 - add transaction
		Transaction transaction = new DepositTransaction(checkingAccount, checkingAccount.getBalance());
		checkingAccount.addTransaction(transaction);
				
		this.checkingAccounts.add(checkingAccount);
		return checkingAccount;
	}

	// return list of all checking account of holder
	public CheckingAccount[] getCheckingAccounts() {
		CheckingAccount[] accounts = this.checkingAccounts.toArray(new CheckingAccount[checkingAccounts.size()]);
		return accounts;
	}

	// return number of all checking account of holder
	public int getNumberOfCheckingAccounts() {
		return this.checkingAccounts.size();
	}

	// return total balance of all checking account
	public double getCheckingBalance() {
		double totalBalance = 0;
		if (this.checkingAccounts != null) {
			for (CheckingAccount account : this.checkingAccounts) {
				totalBalance += account.getBalance();
			}
		}
		return totalBalance;
	}

	// -------------- End of checking account ------------

	// -------------- savings account ------------
	public SavingsAccount addSavingsAccount(double openingBalance) 
		throws ExceedsCombinedBalanceLimitException{
		double totalBalance = getCombinedBalance();
		if ((openingBalance + totalBalance) > MeritBank.accountLimit) {
			//assignment#4 - throw exception
			throw new ExceedsCombinedBalanceLimitException("The combined balance limit is exceeded");
		}

		long newAccountNumber = MeritBank.getNextAccountNumber();

		double interest = 0.01;

		SavingsAccount account = new SavingsAccount(newAccountNumber, openingBalance, interest);
		
		//assignment#4 - add transaction
		Transaction transaction = new DepositTransaction(account, openingBalance);
		account.addTransaction(transaction);
		
		this.savingsAccounts.add(account);
		return account;
	}

	public SavingsAccount addSavingsAccount(SavingsAccount savingsAccount) 
		throws ExceedsCombinedBalanceLimitException{
		double totalBalance = getCombinedBalance();
		if ((savingsAccount.getBalance() + totalBalance) > MeritBank.accountLimit) {
			//assignment#4 - throw exception
			throw new ExceedsCombinedBalanceLimitException("The combined balance limit is exceeded");
		}
		//assignment#4 - add transaction
		Transaction transaction = new DepositTransaction(savingsAccount, savingsAccount.getBalance());
		savingsAccount.addTransaction(transaction);
				
		this.savingsAccounts.add(savingsAccount);
		return savingsAccount;
	}

	public SavingsAccount[] getSavingsAccounts() {
		SavingsAccount[] accounts = this.savingsAccounts.toArray(new SavingsAccount[savingsAccounts.size()]);
		return accounts;
	}

	public int getNumberOfSavingsAccounts() {
		return this.savingsAccounts.size();
	}

	public double getSavingsBalance() {
		double totalBalance = 0;
		if (this.savingsAccounts != null) {
			for (SavingsAccount account : this.savingsAccounts) {
				totalBalance += account.getBalance();
			}
		}
		return totalBalance;
	}
	// -------------- End of savings account ------------

	// -------------- CD account ------------
	public CDAccount addCDAccount(CDOffering offering, double openingBalance) 
		throws ExceedsCombinedBalanceLimitException{
		CDAccount account = new CDAccount(offering, openingBalance);
		//assignment#4 - add transaction
		Transaction transaction = new DepositTransaction(account, openingBalance);
		account.addTransaction(transaction);
				
		return account;
	}

	public CDAccount addCDAccount(CDAccount cdAccount) {
		//assignment#4 - add transaction
		Transaction transaction = new DepositTransaction(cdAccount, cdAccount.getBalance());
		cdAccount.addTransaction(transaction);
		
		this.cdAccounts.add(cdAccount);
		return cdAccount;
	}

	public CDAccount[] getCDAccounts() {
		CDAccount[] accounts = this.cdAccounts.toArray(new CDAccount[this.cdAccounts.size()]);
		return accounts;
	}

	public int getNumberOfCDAccounts() {
		return this.cdAccounts.size();
	}

	public double getCDBalance() {
		double totalBalance = 0;
		if (this.cdAccounts != null) {
			for (CDAccount account : this.cdAccounts) {
				totalBalance += account.getBalance();
			}
		}
		return totalBalance;
	}
	// -------------- End of CD account ------------
	
	public double getCombinedBalance() {
		double totalBalances = 0;

		totalBalances = getCheckingBalance() + getSavingsBalance() + getCDBalance();

		return totalBalances;

	}
	
	//sample data: Doe,S,Jane,0987654321
	public static AccountHolder readFromString(String accountHolderData) 
	{
		AccountHolder accountHolder =  null;
		System.out.println(accountHolderData);
		
		String fname = "";
		String midname = "";
		String lname ="";
		String ssn = "";
		
		try {
			
			StringTokenizer st1 = new StringTokenizer(accountHolderData, ",");
			int index = 0;
			while (st1.hasMoreTokens()) {
				switch (index) {
				case 0:
					fname = st1.nextToken();
					break;
				case 1:
					midname = st1.nextToken();
					break;
				case 2:
					lname = st1.nextToken();
					break;
				case 3:
					ssn = st1.nextToken();
					break;
				default:
					break;
				}
				index++;
			}
		} catch(Exception ex) {
			System.err.println("Exception: "+ex.getMessage());
		} 
		
		accountHolder=new AccountHolder(fname, midname, lname, ssn);
		return  accountHolder; 		   
	}
	
	
	//method such that account holders can be sorted by the combined balance of their accounts
	@Override
    public int compareTo(AccountHolder otherAccountHolder){
    	//sorting in ascending order.
    	if(this.getCombinedBalance() != otherAccountHolder.getCombinedBalance()){
            return Double.compare(this.getCombinedBalance(), otherAccountHolder.getCombinedBalance());  
    	}
    	return 0; 
    }  
	
	public void setCheckingAccounts(CheckingAccount[] accounts){
		for (CheckingAccount account : accounts) 
			checkingAccounts.add(account); 
	}
	public void setSavingsAccounts(SavingsAccount[] accounts){
		for (SavingsAccount account : accounts) 
			savingsAccounts.add(account); 
	}
	public void setCDAccounts(CDAccount[] accounts){
		for (CDAccount account : accounts) 
			cdAccounts.add(account); 
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

}

