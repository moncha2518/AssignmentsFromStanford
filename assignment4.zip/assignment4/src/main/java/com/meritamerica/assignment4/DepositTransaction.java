package com.meritamerica.assignment4;

public class DepositTransaction extends Transaction{
	
	public DepositTransaction(BankAccount bankAccount, double amount){
		setSourceAccount(bankAccount);
		setTargetAccount(bankAccount);
		setAmount(amount);
	}
	
	public void process() throws NegativeAmountException
		, ExceedsAvailableBalanceException, ExceedsFraudSuspicionLimitException{
		
		if (getAmount() < 0){
			throw new NegativeAmountException("Transfer amount should be a positive number");
		}
		if (getAmount() > fraudAmontLimit){
			Transaction depositTrans = new DepositTransaction(getSourceAccount(), getAmount());
			MeritBank.fraudQueue.addTransaction(depositTrans);
			throw new ExceedsFraudSuspicionLimitException("Transfer amount exceeding $1,000 must be reviewed by the fraud team");
		}
		
		getSourceAccount().deposit(getAmount());
	}
}
