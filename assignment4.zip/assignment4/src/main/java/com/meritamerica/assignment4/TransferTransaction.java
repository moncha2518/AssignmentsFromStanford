package com.meritamerica.assignment4;

import java.util.List;

public class TransferTransaction extends Transaction{
	
	public TransferTransaction(BankAccount sourceAccount, BankAccount targetAccount
		, double amount){
		setSourceAccount(sourceAccount);
		setTargetAccount(targetAccount);
		setAmount(amount);
	}
	
	public void process() throws NegativeAmountException
	, ExceedsAvailableBalanceException, ExceedsFraudSuspicionLimitException{
	
		if (getAmount() < 0){
			throw new NegativeAmountException("Transfer amount should be a positive number");
		}
		if (getAmount() > getSourceAccount().getBalance()){
			throw new ExceedsAvailableBalanceException("Transfer amount should be less than balance in source account");
		}
		if (getAmount() > fraudAmontLimit){
			Transaction withdrawTrans = new WithdrawTransaction(getSourceAccount(), getAmount());
			MeritBank.fraudQueue.addTransaction(withdrawTrans);
			throw new ExceedsFraudSuspicionLimitException("Transfer amount exceeding $1,000 must be reviewed by the fraud team");
		}
		
		getSourceAccount().withdraw(getAmount());
		getTargetAccount().deposit(getAmount());
	}
}

