package com.meritamerica.assignment4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MeritBank {
	//private static long seedAccountNumber = 1000001;
	private static ArrayList<AccountHolder> accountHolders =new ArrayList<AccountHolder>();
	private static ArrayList<CDOffering> cdOfferings =new ArrayList<CDOffering>();
	
	public static double accountLimit = 250000;
	
	public static long nextAccountNumber = 0;
	
	public static DecimalFormat numberformat = new DecimalFormat("#,###,##0.00");
	
	public static FraudQueue fraudQueue = new FraudQueue();
	
	public static void addAccountHolder(AccountHolder accountHolder){
		accountHolders.add(accountHolder);
	}
	
	public static AccountHolder[] getAccountHolders(){
		AccountHolder[] accounts=  accountHolders.toArray(new AccountHolder[accountHolders.size()]);
		return accounts;
	}
	
	public static CDOffering[] getCDOfferings(){
		CDOffering[] accounts=  cdOfferings.toArray(new CDOffering[cdOfferings.size()]);
		return accounts;
	}
	
	public static CDOffering getBestCDOffering(double depositAmount){
		System.out.println("cdOfferings.size()="+cdOfferings.size());
		if(cdOfferings.size()<=0){
			return null;
		}
		ArrayList<Double> offerAmounts = new ArrayList<Double>();
		for (int i=0; i<cdOfferings.size(); i++) {
			offerAmounts.add(depositAmount*cdOfferings.get(i).getInterestRate());
		}
		int bestIndex = getMax(offerAmounts, -1);
		return cdOfferings.get(bestIndex);

	}
	
	public static CDOffering getSecondBestCDOffering(double depositAmount){
		System.out.println("cdOfferings.size()="+cdOfferings.size());
		
		if(cdOfferings.size()<=0){
			return null;
		}
		ArrayList<Double> offerAmounts = new ArrayList<Double>();
		for (int i=0; i<cdOfferings.size(); i++) {
			offerAmounts.add(depositAmount*cdOfferings.get(i).getInterestRate());
		}
		int bestIndex = getMax(offerAmounts, -1);
		double bestOffer = (double) offerAmounts.get(bestIndex);
		int secondIndex = getMax(offerAmounts, bestOffer);
		
		return cdOfferings.get(secondIndex);
	}
	
	// Method for getting the max value and place of value
	public static int getMax(ArrayList<Double> valueList, double valueCompare){ 
		double maxValue = valueList.get(0); 
		int maxIndex = 0;
		for(int i=1;i < valueList.size();i++){ 
		  boolean isMax = false;
		  double value = valueList.get(i);
		  if (valueCompare<0){
			  isMax = value > maxValue;
		  }else{
			  isMax = (value > maxValue) && (value < valueCompare);
		  }
		  
		  if(isMax){ 
		     maxValue = value; 
		     maxIndex = i;
		  } 
		} 
		
		return maxIndex; 
	}
	
	public static void clearCDOfferings(){
		cdOfferings.clear();
		cdOfferings = null;
	}
	
	public static void setCDOfferings(CDOffering[] offerings){
		//cdOfferings = offerings.asL;
		for (CDOffering offering : offerings) 
			cdOfferings.add(offering); 
	}
	
	public static void setAccountHolders(AccountHolder[] holders){
		for (AccountHolder holder : holders) 
			accountHolders.add(holder); 
	}
	
	
	/*
	public static long getNextAccountNumber(){
		seedAccountNumber += 1;
		return seedAccountNumber;
	}*/
	
	public static long getNextAccountNumber(){
		long seedAccountNumber = MeritBank.nextAccountNumber;
		MeritBank.nextAccountNumber = seedAccountNumber+1;
		
		return seedAccountNumber;
	}
	
	// total balance for all accountholder and all account type??
	public static double totalBalances(){
		double totalBalances = 0;
		for (AccountHolder accountHolder : accountHolders) {
			totalBalances += accountHolder.getCombinedBalance();
		}
		return totalBalances;
	}

	public static double futureValue(double presentValue, double interestRate, int term){
		double futureBalance = recursiveFutureValue(presentValue, term, interestRate);
		return futureBalance;
	}
	
	
	//*************************//
	public String writetoString() {
		return "Next bank account number : " +MeritBank.nextAccountNumber+'\n'+MeritBank.totalBalances()+" CD offerings";
	}
	
	public static void setNextAccountNumber(long nextAccountNumber){
		MeritBank.nextAccountNumber = nextAccountNumber;
	}
	
	//--------------------------To create & write to a new file -------------------------------
	public static boolean writeToFile_assignment3(String fileName) throws IOException {
		try {
			File myObject = new File(
					"/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			if (myObject.createNewFile()) {
				System.out.println("File created: " + myObject.getName());
			} else {
				System.out.println("File already exists.");
			}
			FileWriter myWriter = new FileWriter(
					"/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			myWriter.write("Files in Java might be tricky, but it is fun enough!");
			myWriter.close();
			System.out.println("Successfully wrote to the file.");

		} catch (IOException e) {
			System.out.println("IOException got caught");
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//--------------------------End To create & write to a new file----------------------------

		
	//--------------------------To read a data from text file----------------------
	public static boolean readFromFile_assignment3(String fileName) {
		Scanner myReader = null;
		try {
			File myObject = new File(fileName);
			myReader = new Scanner(myObject);
			if (myObject.exists()) {
				String data = "";
				if (myReader.hasNext()) {
					
					//set next account
					data = myReader.nextLine();
					MeritBank.setNextAccountNumber(Long.parseLong(data)); 	
					
					//set CDOffering
					data = myReader.nextLine();
					int no_offering = Integer.parseInt(data);
					CDOffering[] offerings = new CDOffering[no_offering];
					for (int i=0; i<no_offering; i++){
						data = myReader.nextLine();
						CDOffering offering = CDOffering.readFromString(data);
						offering.setDescription("");
						offerings[i]= offering;
					}
					MeritBank.setCDOfferings(offerings);
					
					//set AccountHolder
					data = myReader.nextLine();
					int no_holder = Integer.parseInt(data);
					AccountHolder[] holders = new AccountHolder[no_holder];
					for (int i=0; i<no_holder; i++){
						data = myReader.nextLine();
						AccountHolder holder = AccountHolder.readFromString(data);
						System.out.println("MeritBank.getNextAccountNumber()="+MeritBank.getNextAccountNumber());
						holder.setAccountNumber(MeritBank.getNextAccountNumber());
						
						//set checking account
						data = myReader.nextLine();
						int no_checkaccount = Integer.parseInt(data);
						CheckingAccount[] checkaccounts = new CheckingAccount[no_checkaccount];
						for (int k=0; k<no_checkaccount; k++){
							data = myReader.nextLine();
							CheckingAccount checkaccount = CheckingAccount.readFromString(data);
							checkaccounts[k]= checkaccount;
						}
						holder.setCheckingAccounts(checkaccounts);
						
						
						//set saving account
						data = myReader.nextLine();
						int no_savingaccount = Integer.parseInt(data);
						SavingsAccount[] savingaccounts = new SavingsAccount[no_savingaccount];
						for (int k=0; k<no_savingaccount; k++){
							data = myReader.nextLine();
							SavingsAccount savingaccount = SavingsAccount.readFromString(data);
							savingaccounts[k]= savingaccount;
						}
						holder.setSavingsAccounts(savingaccounts);
						
						
						//set CD account
						data = myReader.nextLine();
						int no_cdaccount = Integer.parseInt(data);
						CDAccount[] cdaccounts = new CDAccount[no_cdaccount];
						for (int k=0; k<no_cdaccount; k++){
							data = myReader.nextLine();
							CDAccount cdaccount = CDAccount.readFromString(data);
							cdaccounts[k]= cdaccount;
						}
						holder.setCDAccounts(cdaccounts);
						
						holders[i]= holder;
					}
					MeritBank.setAccountHolders(holders);
				}
			}
		} catch (IOException e) {
			System.out.println("File Not Found Exception get caught!");
			return false;
		} catch (Exception e) {
			System.out.println("Exception!, "+e.getMessage());
			return false;
		} finally {
			if (myReader!=null)
				myReader.close();
		}
		return true;
	}
	
	public static AccountHolder[] sortAccountHolders(){
		Arrays.sort(MeritBank.getAccountHolders());
		return MeritBank.getAccountHolders();
		
	}

	/**
	 * Assignment#4
	 */

	public static double recursiveFutureValue(double amount, int years, double interestRate) {
		double result=ExistingFutureValue(years, interestRate);
		return (amount*result);
	}
	
	public static double ExistingFutureValue(int years, double interestRate) 
	{
		double result=1;
		if (years>0) { 
			result=(1+interestRate);
			for (int i=1; i<years; i++) {
				result= result*(1+interestRate);
			}
		}
		return result;
	}
	
	public static FraudQueue getFraudQueue(){
		return MeritBank.fraudQueue;
	}
	
	public static BankAccount getBankAccount(long accountId){
		BankAccount bankAccount = null;
		for (AccountHolder accountHolder : accountHolders) {
			if (accountHolder!=null){
				
				BankAccount[] checkingAccounts = accountHolder.getCheckingAccounts();
				for (BankAccount checkingAccount : checkingAccounts) {
					if (accountId == checkingAccount.getAccountNo()){
						bankAccount = checkingAccount;
						break;
					}
				}
				BankAccount[] savingsAccounts = accountHolder.getSavingsAccounts();
				for (BankAccount savingsAccount : savingsAccounts) {
					if (accountId == savingsAccount.getAccountNo()){
						bankAccount = savingsAccount;
						break;
					}
				}
				BankAccount[] cdAccounts = accountHolder.getCDAccounts();
				for (BankAccount cdAccount : cdAccounts) {
					if (accountId == cdAccount.getAccountNo()){
						bankAccount = cdAccount;
						break;
					}
				}
			}
		}
		return bankAccount;
	}
	
	public static boolean processTransaction(Transaction transaction) 
		throws NegativeAmountException, ExceedsAvailableBalanceException
		, ExceedsFraudSuspicionLimitException{
		
		try{
			transaction.process();
			
		}catch (NegativeAmountException ex){
			throw new NegativeAmountException(ex.getMessage());	
		}catch (ExceedsAvailableBalanceException ex){
			throw new ExceedsAvailableBalanceException(ex.getMessage());	
		}catch (ExceedsFraudSuspicionLimitException ex){
			throw new ExceedsFraudSuspicionLimitException(ex.getMessage());	
		}
		return true;
	}

	/**
	 * Should also read BankAccount transactions and the FraudQueue
	 * @assignment#4
	 */
	public static boolean readFromFile(String fileName) {
		ArrayList<String> transactionLists = new ArrayList<String>();
		Scanner myReader = null;
		try {
			File myObject = new File(fileName);
			myReader = new Scanner(myObject);
			if (myObject.exists()) {
				String data = "";
				if (myReader.hasNext()) {
					
					//set next account
					data = myReader.nextLine();
					MeritBank.setNextAccountNumber(Long.parseLong(data)); 	
					
					//set CDOffering
					data = myReader.nextLine();
					int no_offering = Integer.parseInt(data);
					CDOffering[] offerings = new CDOffering[no_offering];
					for (int i=0; i<no_offering; i++){
						data = myReader.nextLine();
						CDOffering offering = CDOffering.readFromString(data);
						offering.setDescription("");
						offerings[i]= offering;
					}
					MeritBank.setCDOfferings(offerings);
					
					//set AccountHolder
					data = myReader.nextLine();
					int no_holder = Integer.parseInt(data);
					AccountHolder[] holders = new AccountHolder[no_holder];
					for (int i=0; i<no_holder; i++){
						data = myReader.nextLine();
						AccountHolder holder = AccountHolder.readFromString(data);
						System.out.println("MeritBank.getNextAccountNumber()="+MeritBank.getNextAccountNumber());
						holder.setAccountNumber(MeritBank.getNextAccountNumber());
						
						//set checking account
						data = myReader.nextLine();
						int no_checkaccount = Integer.parseInt(data);
						CheckingAccount[] checkaccounts = new CheckingAccount[no_checkaccount];
						for (int k=0; k<no_checkaccount; k++){
							data = myReader.nextLine();
							CheckingAccount checkaccount = CheckingAccount.readFromString(data);
							
							//do transactions - assignment4
							data = myReader.nextLine();
							int no_transaction = Integer.parseInt(data);
							for (int t=0; t<no_transaction; t++){
								data = myReader.nextLine();
								//Transaction transaction = Transaction.readFromString(data);
								//checkaccount.addTransaction(transaction);
								transactionLists.add(data);
							}
						
							checkaccounts[k]= checkaccount;
						}
						holder.setCheckingAccounts(checkaccounts);
						
						//set saving account
						data = myReader.nextLine();
						int no_savingaccount = Integer.parseInt(data);
						SavingsAccount[] savingaccounts = new SavingsAccount[no_savingaccount];
						for (int k=0; k<no_savingaccount; k++){
							data = myReader.nextLine();
							SavingsAccount savingaccount = SavingsAccount.readFromString(data);
							
							//do transactions - assignment4
							data = myReader.nextLine();
							int no_transaction = Integer.parseInt(data);
							for (int t=0; t<no_transaction; t++){
								data = myReader.nextLine();
								//Transaction transaction = Transaction.readFromString(data);
								//savingaccount.addTransaction(transaction);
								transactionLists.add(data);
							}
							
							savingaccounts[k]= savingaccount;
						}
						holder.setSavingsAccounts(savingaccounts);

						//set CD account
						data = myReader.nextLine();
						int no_cdaccount = Integer.parseInt(data);
						CDAccount[] cdaccounts = new CDAccount[no_cdaccount];
						for (int k=0; k<no_cdaccount; k++){
							data = myReader.nextLine();
							CDAccount cdaccount = CDAccount.readFromString(data);
							
							//do transactions - assignment4
							data = myReader.nextLine();
							int no_transaction = Integer.parseInt(data);
							for (int t=0; t<no_transaction; t++){
								data = myReader.nextLine();
								//Transaction transaction = Transaction.readFromString(data);
								//cdaccount.addTransaction(transaction);
								transactionLists.add(data);
							}
							
							cdaccounts[k]= cdaccount;
						}
						holder.setCDAccounts(cdaccounts);
							
						holders[i]= holder;
					}
					//Fraud
					data = myReader.nextLine();
					int no_fraud = Integer.parseInt(data);
					for (int k=0; k<no_fraud; k++){
						data = myReader.nextLine();
						transactionLists.add(data);
					}
					
					MeritBank.setAccountHolders(holders);
					
					//for transaction process
					for (int i=0; i<transactionLists.size(); i++){
						String trans_data = transactionLists.get(i);
						Transaction transaction = Transaction.readFromString(trans_data);
						BankAccount account = transaction.getSourceAccount();
						account.addTransaction(transaction);
						
						MeritBank.processTransaction(transaction);
					}
					
				}
			}
		} catch (IOException e) {
			System.out.println("File Not Found Exception get caught!");
			return false;
		} catch (Exception e) {
			System.out.println("Exception!, "+e.getMessage());
			return false;
		} finally {
			if (myReader!=null)
				myReader.close();
		}
		return true;
	}
	
	//i.	Should also write BankAccount transactions and the FraudQueue
	public static boolean writeToFile(String fileName){
		
		try {
			File myObject = new File(fileName);
			/*if (myObject.createNewFile()) {
				System.out.println("File created: " + myObject.getName());
			} else {
				System.out.println("File already exists.");
			}*/
			
			PrintWriter printer = new PrintWriter(fileName);

			printer.println("MeritBank.getNextAccountNumber = "+MeritBank.getNextAccountNumber());
			
			CDOffering[] offers = MeritBank.getCDOfferings();
			for (int i=0; i<offers.length; i++){
				CDOffering offer = offers[i];
				printer.println("CDOffering["+i+"]= "+offer.writetoString());
			}
			
			AccountHolder[] holders = MeritBank.getAccountHolders();
			for (int i=0; i<holders.length; i++){
				AccountHolder holder = holders[i];
				printer.println("AccountHolder["+i+"]= "+holder.writetoString());
				
				CheckingAccount[] caccounts = holder.getCheckingAccounts();
				if (caccounts!=null && caccounts.length>0){
					for (int k=0; k<caccounts.length; k++){
						CheckingAccount caccount = caccounts[k];
						printer.println("CheckingAccount["+k+"]= "+caccount.writetoString());
						
						List<Transaction> transactions = caccount.getTransactions();
						for(Transaction transact: transactions){
							printer.println(""+transact.writeToString());
						}
					}
				}
				
				SavingsAccount[] saccounts = holder.getSavingsAccounts();
				if (saccounts!=null && saccounts.length>0){
					for (int k=0; k<saccounts.length; k++){
						SavingsAccount saccount = saccounts[k];
						printer.println("SavingsAccount["+k+"]= "+saccount.writetoString());
						
						List<Transaction> transactions = saccount.getTransactions();
						for(Transaction transact: transactions){
							printer.println(""+transact.writeToString());
						}
					}
				}
				

				CDAccount[] cdaccounts = holder.getCDAccounts();
				if (cdaccounts!=null && cdaccounts.length>0){
					for (int k=0; k<cdaccounts.length; k++){
						CDAccount cdaccount = cdaccounts[k];
						printer.println("CDAccount["+k+"]= "+cdaccount.writetoString());
						
						List<Transaction> transactions = cdaccount.getTransactions();
						for(Transaction transact: transactions){
							printer.println(""+transact.writeToString());
						}
					}
				}
			}
			
			if (holders!=null && holders.length>0){
				for(AccountHolder holder: holders){
					printer.println("sorting: "+holder.writetoString());
			   }
			}
			printer.close();
			printer.println("Successfully wrote to the file.");
			

		} catch (IOException e) {
			System.out.println("IOException got caught");
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
