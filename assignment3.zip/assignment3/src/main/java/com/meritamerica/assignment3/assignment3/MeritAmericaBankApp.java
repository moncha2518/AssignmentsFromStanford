package com.meritamerica.assignment3;

public class MeritAmericaBankApp {

	public static void main(String[] args) {
		System.out.println("=== Welcome to Assignment III - Merit America Bank  ===");
		
		MeritBank meritBank = new MeritBank();
	//	MeritBank.readFromFile("src/test/testMeritBank_bad.txt");
 	
		boolean result = MeritBank.readFromFile("src/test/testMeritBank_good.txt");
		System.out.println("=== Read File: "+result+"  ===");
		
		
		System.out.println("===================== Result ==================");
		
		System.out.println("MeritBank.getNextAccountNumber = "+MeritBank.getNextAccountNumber());
		
		CDOffering[] offers = MeritBank.getCDOfferings();
		for (int i=0; i<offers.length; i++){
			CDOffering offer = offers[i];
			System.out.println("CDOffering["+i+"]= "+offer.writetoString());
		}
		
		AccountHolder[] holders = MeritBank.getAccountHolders();
		for (int i=0; i<holders.length; i++){
			AccountHolder holder = holders[i];
			System.out.println("AccountHolder["+i+"]= "+holder.writetoString());
			
			CheckingAccount[] caccounts = holder.getCheckingAccounts();
			if (caccounts!=null && caccounts.length>0){
				for (int k=0; k<caccounts.length; k++){
					CheckingAccount caccount = caccounts[k];
					System.out.println("CheckingAccount["+k+"]= "+caccount.writetoString());
				}
			}
			
			SavingsAccount[] saccounts = holder.getSavingsAccounts();
			if (saccounts!=null && saccounts.length>0){
				for (int k=0; k<saccounts.length; k++){
					SavingsAccount saccount = saccounts[k];
					System.out.println("SavingsAccount["+k+"]= "+saccount.writetoString());
				}
			}
			

			CDAccount[] cdaccounts = holder.getCDAccounts();
			if (cdaccounts!=null && cdaccounts.length>0){
				for (int k=0; k<cdaccounts.length; k++){
					CDAccount cdaccount = cdaccounts[k];
					System.out.println("CDAccount["+k+"]= "+cdaccount.writetoString());
				}
			}
		}
		
		if (holders!=null && holders.length>0){
			for(AccountHolder holder: holders){
				System.out.println("sorting: "+holder.writetoString());
		   }
		}
	}

}
