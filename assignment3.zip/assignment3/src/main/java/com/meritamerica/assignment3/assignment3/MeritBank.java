package com.meritamerica.assignment3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class MeritBank {
	//private static long seedAccountNumber = 1000001;
	
	private static ArrayList<AccountHolder> accountHolders =new ArrayList<AccountHolder>();
	private static ArrayList<CDOffering> cdOfferings =new ArrayList<CDOffering>();
	
	public static double accountLimit = 250000;
	
	public static long nextAccountNumber = 0;
	
	public static DecimalFormat numberformat = new DecimalFormat("#,###,##0.00");
	
	public static void addAccountHolder(AccountHolder accountHolder){
		accountHolders.add(accountHolder);
	}
	
	public static AccountHolder[] getAccountHolders(){
		AccountHolder[] accounts=  accountHolders.toArray(new AccountHolder[accountHolders.size()]);
		return accounts;
	}
	
	public static CDOffering[] getCDOfferings(){
		CDOffering[] accounts=  cdOfferings.toArray(new CDOffering[cdOfferings.size()]);
		return accounts;
	}
	
	public static CDOffering getBestCDOffering(double depositAmount){
		System.out.println("cdOfferings.size()="+cdOfferings.size());
		if(cdOfferings.size()<=0){
			return null;
		}
		ArrayList<Double> offerAmounts = new ArrayList<Double>();
		for (int i=0; i<cdOfferings.size(); i++) {
			offerAmounts.add(depositAmount*cdOfferings.get(i).getInterestRate());
		}
		int bestIndex = getMax(offerAmounts, -1);
		return cdOfferings.get(bestIndex);

	}
	
	public static CDOffering getSecondBestCDOffering(double depositAmount){
		System.out.println("cdOfferings.size()="+cdOfferings.size());
		
		if(cdOfferings.size()<=0){
			return null;
		}
		ArrayList<Double> offerAmounts = new ArrayList<Double>();
		for (int i=0; i<cdOfferings.size(); i++) {
			offerAmounts.add(depositAmount*cdOfferings.get(i).getInterestRate());
		}
		int bestIndex = getMax(offerAmounts, -1);
		double bestOffer = (double) offerAmounts.get(bestIndex);
		int secondIndex = getMax(offerAmounts, bestOffer);
		
		return cdOfferings.get(secondIndex);
	}
	
	// Method for getting the max value and place of value
	public static int getMax(ArrayList<Double> valueList, double valueCompare){ 
		double maxValue = valueList.get(0); 
		int maxIndex = 0;
		for(int i=1;i < valueList.size();i++){ 
		  boolean isMax = false;
		  double value = valueList.get(i);
		  if (valueCompare<0){
			  isMax = value > maxValue;
		  }else{
			  isMax = (value > maxValue) && (value < valueCompare);
		  }
		  
		  if(isMax){ 
		     maxValue = value; 
		     maxIndex = i;
		  } 
		} 
		
		return maxIndex; 
	}
	
	public static void clearCDOfferings(){
		cdOfferings.clear();
		cdOfferings = null;
	}
	
	public static void setCDOfferings(CDOffering[] offerings){
		//cdOfferings = offerings.asL;
		for (CDOffering offering : offerings) 
			cdOfferings.add(offering); 
	}
	
	public static void setAccountHolders(AccountHolder[] holders){
		for (AccountHolder holder : holders) 
			accountHolders.add(holder); 
	}
	
	
	/*
	public static long getNextAccountNumber(){
		seedAccountNumber += 1;
		return seedAccountNumber;
	}*/
	
	
	public static long getNextAccountNumber(){
		long seedAccountNumber = MeritBank.nextAccountNumber;
		MeritBank.nextAccountNumber = seedAccountNumber+1;
		
		return seedAccountNumber;
	}
	
	// total balance for all accountholder and all account type??
	public static double totalBalances(){
		double totalBalances = 0;
		for (AccountHolder accountHolder : accountHolders) {
			totalBalances += accountHolder.getCombinedBalance();
		}
		return totalBalances;
	}

	//******** future value, what is formula?
	public static double futureValue(double presentValue, double interestRate, int term){
		double futureBalanace = 0;
		return futureBalanace;
	}
	
	
	//*************************//
	public String writetoString() {
		return "Next bank account number : " +MeritBank.nextAccountNumber+'\n'+MeritBank.totalBalances()+" CD offerings";
	}
	
	public static void setNextAccountNumber(long nextAccountNumber){
		MeritBank.nextAccountNumber = nextAccountNumber;
	}
	
	//--------------------------To create & write to a new file -------------------------------
	public static boolean writeToFile(String fileName) throws IOException {
		try {
			File myObject = new File(
					"/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			if (myObject.createNewFile()) {
				System.out.println("File created: " + myObject.getName());
			} else {
				System.out.println("File already exists.");
			}
			FileWriter myWriter = new FileWriter(
					"/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			myWriter.write("Files in Java might be tricky, but it is fun enough!");
			myWriter.close();
			System.out.println("Successfully wrote to the file.");

		} catch (IOException e) {
			System.out.println("IOException got caught");
			e.printStackTrace();
			return false;
		}
		return true;

	}
	//--------------------------End To create & write to a new file----------------------------

		
	//--------------------------To read a data from text file----------------------
	public static boolean readFromFile(String fileName) {
		Scanner myReader = null;
		try {
			File myObject = new File(fileName);
			myReader = new Scanner(myObject);
			if (myObject.exists()) {
				String data = "";
				if (myReader.hasNext()) {
					
					//set next account
					data = myReader.nextLine();
					MeritBank.setNextAccountNumber(Long.parseLong(data)); 	
					
					//set CDOffering
					data = myReader.nextLine();
					int no_offering = Integer.parseInt(data);
					CDOffering[] offerings = new CDOffering[no_offering];
					for (int i=0; i<no_offering; i++){
						data = myReader.nextLine();
						CDOffering offering = CDOffering.readFromString(data);
						offering.setDescription("");
						offerings[i]= offering;
					}
					MeritBank.setCDOfferings(offerings);
					
					//set AccountHolder
					data = myReader.nextLine();
					int no_holder = Integer.parseInt(data);
					AccountHolder[] holders = new AccountHolder[no_holder];
					for (int i=0; i<no_holder; i++){
						data = myReader.nextLine();
						AccountHolder holder = AccountHolder.readFromString(data);
						System.out.println("MeritBank.getNextAccountNumber()="+MeritBank.getNextAccountNumber());
						holder.setAccountNumber(MeritBank.getNextAccountNumber());
						
						//set checking account
						data = myReader.nextLine();
						int no_checkaccount = Integer.parseInt(data);
						CheckingAccount[] checkaccounts = new CheckingAccount[no_checkaccount];
						for (int k=0; k<no_checkaccount; k++){
							data = myReader.nextLine();
							CheckingAccount checkaccount = CheckingAccount.readFromString(data);
							checkaccounts[k]= checkaccount;
						}
						holder.setCheckingAccounts(checkaccounts);
						
						
						//set saving account
						data = myReader.nextLine();
						int no_savingaccount = Integer.parseInt(data);
						SavingsAccount[] savingaccounts = new SavingsAccount[no_savingaccount];
						for (int k=0; k<no_savingaccount; k++){
							data = myReader.nextLine();
							SavingsAccount savingaccount = SavingsAccount.readFromString(data);
							savingaccounts[k]= savingaccount;
						}
						holder.setSavingsAccounts(savingaccounts);
						
						
						//set CD account
						data = myReader.nextLine();
						int no_cdaccount = Integer.parseInt(data);
						CDAccount[] cdaccounts = new CDAccount[no_cdaccount];
						for (int k=0; k<no_cdaccount; k++){
							data = myReader.nextLine();
							CDAccount cdaccount = CDAccount.readFromString(data);
							cdaccounts[k]= cdaccount;
						}
						holder.setCDAccounts(cdaccounts);
						
						holders[i]= holder;
					}
					MeritBank.setAccountHolders(holders);
				}
			}
		} catch (IOException e) {
			System.out.println("File Not Found Exception get caught!");
			return false;
		} catch (Exception e) {
			System.out.println("Exception!, "+e.getMessage());
			return false;
		} finally {
			if (myReader!=null)
				myReader.close();
		}
		return true;
	}
	
	public static AccountHolder[] sortAccountHolders(){
		Arrays.sort(MeritBank.getAccountHolders());
		return MeritBank.getAccountHolders();
		
	}	
}
