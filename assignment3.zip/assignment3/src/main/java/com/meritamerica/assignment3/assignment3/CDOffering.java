package com.meritamerica.assignment3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class CDOffering {
	
	private int term;
	private double interestRate;
	private String description;
	
	public CDOffering(int term, double interestRate){
		this.term = term;
		this.interestRate = interestRate;
	}
	
	public CDOffering(int term, double interestRate, String description) {
		this.term = term;
		this.interestRate = interestRate;
		this.description = description;

	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	//sample data: 1,0.018
	public static CDOffering readFromString(String cdOfferingDataString)
	{
		CDOffering cdOffering =  null;
		System.out.println(cdOfferingDataString);
		
		int term = 0;
		double interest = 0;
		
		try {
			StringTokenizer st1 = new StringTokenizer(cdOfferingDataString , ",");
			int index = 0;
			while (st1.hasMoreTokens()) {
				switch (index) {
				case 0:
					term = Integer.parseInt(st1.nextToken());
					break;
				case 1:
					interest = Double.parseDouble(st1.nextToken());
					break;
				default:
					break;
				}
				index++;
			}
			cdOffering = new CDOffering(term, interest);
		}  
		catch (NumberFormatException nex) {
			System.err.println("NumberFormatExcepton is Handled!, "+nex.getMessage());
		}
		return cdOffering; 
	}
	
	public String writetoString() {
		return "CDOffering: " + this.getTerm()
		+ "|" + MeritBank.numberformat.format(this.getInterestRate()) + "|"+ this.getDescription();
	}
}
