
package com.meritamerica.assignment3;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;

public class BankAccount {

	private long accountNo;
	private double balance;
	private double interestRate;
	private Date accountOpenedOn;

	public BankAccount(double balance, double interestRate) {
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public BankAccount(double balance, double interestRate, Date accountOpenedOn) {
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountOpenedOn = accountOpenedOn;
	}

	public BankAccount(long accountNo, double balance, double interestRate
	, Date accountOpenedOn) {
		this.accountNo = accountNo;
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountOpenedOn = accountOpenedOn;
	}
	
	public BankAccount(long accountNo, double balance, double interestRate) {
		this.accountNo = accountNo;
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public BankAccount(double balance) {
		this.balance = balance;
		this.interestRate = 0;
	}

	public long getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return this.balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterestRate() {
		return this.interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public boolean withdraw(double amount) {
		if (amount >= 0 && amount <= this.balance) {
			this.balance -= amount;
			return true;
		} else {
			return false;
		}
	}

	public boolean deposit(double amount) {
		if (amount >= 0) {
			this.balance += amount;
			return true;
		} else {
			return false;
		}
	}

	public double futureValue(int years) {
		double futureBalanace = this.balance * Math.pow((1 + this.interestRate), years);
		return futureBalanace;
	}
	
	public Date getOpenedOn() {
		return this.accountOpenedOn;
	}
	
	public void setOpenedOn(Date accountOpenedOn) {
		this.accountOpenedOn = accountOpenedOn;
	}

	
	public static BankAccount readFromString(String accountData) {
		BankAccount bankAccount =  null;
		System.out.println(accountData);
		
		long accountno = 0;
		double balance = 0;
		double interest = 0;
		Date accountdate = new Date();
		
		try {
			StringTokenizer st1 = new StringTokenizer(accountData , ",");
			int index = 0;
			while (st1.hasMoreTokens()) {
				switch (index) {
				case 0:
					accountno = Long.parseLong(st1.nextToken());
					break;
				case 1:
					balance = Double.parseDouble(st1.nextToken());
					break;
				case 2:
					interest = Double.parseDouble(st1.nextToken());
					break;
				case 3:
					accountdate = new SimpleDateFormat("MM/dd/yyyy").parse(st1.nextToken());
					break;
				default:
					break;
				}
				index++;
			}
			bankAccount = new BankAccount(accountno, balance, interest, accountdate);
		}  
		catch (ParseException pex) {
			System.err.println("ParseException: "+pex.getMessage());
		} catch (NumberFormatException nex) {
			System.err.println("NumberFormatExcepton is Handled!, "+nex.getMessage());
		}
		return bankAccount; 
	}
	
	public String writetoString() {
		return "BankAccount: " + this.getAccountNo() 
		+ "|" + MeritBank.numberformat.format(this.getBalance()) 
		+ "|" + MeritBank.numberformat.format(this.getInterestRate()) 
		+ "|" + this.getOpenedOn();
	}
}
