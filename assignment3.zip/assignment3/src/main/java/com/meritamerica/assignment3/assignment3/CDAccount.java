package com.meritamerica.assignment3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;

public class CDAccount extends BankAccount{
	private int term;
	private double balance;
	private Date startDate;
	
	private CDOffering offering;
	
	
	public CDAccount(CDOffering offering, double balance){
		super(balance, offering.getInterestRate());
		
		this.balance = balance;
		this.offering = offering;
	}
	
	public CDAccount(long accountNo, double balance, double interestRate 
	, Date accountOpenedOn) {
		super(accountNo, balance, interestRate, accountOpenedOn);
	}
	
	public int getTerm(){
		this.term = this.offering.getTerm();
		return this.term;
	}
	public void setTerm(int term){
		this.term = term;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Date getStartDate(){
		return startDate;
	}

	public CDOffering getOffering() {
		return offering;
	}

	public void setOffering(CDOffering offering) {
		this.offering = offering;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	
	//Override the deposit and withdraw methods to return false (CD Accounts cannot
	//deposit new funds or withdraw funds until the term is reached)
	//calculate term with opened date
	@Override
	public boolean withdraw(double amount) 
	{
		int diffMonth = getDiffMonth(this.getOpenedOn(), new Date());
		if ((diffMonth > this.term ) && (amount >= 0)) {
			this.balance -= amount;
			return true;
		} else {
			return false;
		}
	}
	@Override
	public boolean deposit(double amount) {
		int diffMonth = getDiffMonth(this.getOpenedOn(), new Date());
		if ((diffMonth > this.term ) && (amount >= 0)) {
			this.balance += amount;
			return true;
		} else {
			return false;
		}
	}
	
	public int getDiffMonth(Date fromdate, Date todate)
	{
		int diff_month = 0;
		
		Calendar c_fromdate = Calendar.getInstance();
		c_fromdate.setTime(fromdate);
		Calendar t_fromdate = Calendar.getInstance();
		t_fromdate.setTime(todate);
		
		diff_month = Math.abs(c_fromdate.get(Calendar.DAY_OF_MONTH) - t_fromdate.get(Calendar.DAY_OF_MONTH));
		
		return diff_month;
	}

	public String CDAccount() {
		return "SavingAccount: " + this.getAccountNo() 
		+ "|" + MeritBank.numberformat.format(this.getBalance()) 
		+ "|" + MeritBank.numberformat.format(this.getInterestRate()) 
		+ "|" + this.getOpenedOn()+ "|" + this.getTerm();
		
	}
	
	//10,5000,0.025,01/01/2020,10
	public static CDAccount readFromString(String accountData) {
		CDAccount bankAccount =  null;
		System.out.println(accountData);
		
		long accountno = 0;
		double balance = 0;
		double interest = 0;
		Date accountdate = new Date();
		int term = 0;
		
		try {
			StringTokenizer st1 = new StringTokenizer(accountData , ",");
			int index = 0;
			while (st1.hasMoreTokens()) {
				switch (index) {
				case 0:
					accountno = Long.parseLong(st1.nextToken());
					break;
				case 1:
					balance = Double.parseDouble(st1.nextToken());
					break;
				case 2:
					interest = Double.parseDouble(st1.nextToken());
					break;
				case 3:
					accountdate = new SimpleDateFormat("MM/dd/yyyy").parse(st1.nextToken());
					break;
				case 4:
					term = Integer.parseInt(st1.nextToken());
					break;
				default: 	
					break;
				}
				index++;
			}
			bankAccount = new CDAccount(accountno, balance, interest, accountdate);
			bankAccount.setTerm(term);
		}  
		catch (ParseException pex) {
			System.err.println("ParseException: "+pex.getMessage());
		} catch (NumberFormatException nex) {
			System.err.println("NumberFormatExcepton is Handled!, "+nex.getMessage());
		}
		return bankAccount; 
	}

}
