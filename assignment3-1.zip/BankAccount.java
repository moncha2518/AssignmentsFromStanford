
package com.meritamerica.assignment3;

import java.util.Date;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.text.DateFormat;
import java.text.ParseException; 
import java.util.StringTokenizer;

public class BankAccount {

	private long accountNumber;
	private double balance;
	private double interestRate;
	private Date accountOpenedOn;

	public BankAccount(double balance, double interestRate) {
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public BankAccount(double balance, double interestRate, Date accountOpenedOn) {
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountOpenedOn = accountOpenedOn;
	}

	public BankAccount(long accountNumber, double balance, double interestRate, Date accountOpenedOn) {
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountOpenedOn = accountOpenedOn;
	}
	public BankAccount(long accountNumber, double balance, double interestRate) {
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.interestRate = interestRate;
		
	}


	
	public Date getOpenedOn() {
		return this.accountOpenedOn;
	}
	/*
	public Date setOpenedOn() {
		this.accountOpenedOn=accountOpenedOn;
	}
	*/

	
	public void setOpenedOn(Date accountOpenedOn) {
		this.accountOpenedOn = accountOpenedOn;
	}
//ParseException , if the date string could not be parsed
	
	public static BankAccount readFromString(String accountData) throws ParseException {
		String filePath = ("src/test/testMeritBank_good.txt");
		 
		try {
		    BufferedReader lineReader = new BufferedReader(new FileReader(filePath));
		    String lineText = null;
		    if (lineReader == null)
		    {
		    	return null;
		    }
		 
		    while ((lineText = lineReader.readLine()) != null) {
		    		System.out.println(lineText);
		    		StringTokenizer st1 = new StringTokenizer(lineText , ","); //1,0.018
		    		while (st1.hasMoreTokens()) {
		    			System.out.println(st1.nextToken());
		    		}
		       
		    }
		   
		    lineReader.close();
		}  
	 catch (IOException ex) {
		    System.err.println(ex);
		} catch (NumberFormatException e) {
			System.out.println("NumberFormatExcepton is Handled!");
		}
return null; //has to be fixed
	
	}

	public BankAccount(double balance) {
		this.balance = balance;
		this.interestRate = 0;
	}

	public long getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return this.balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterestRate() {
		return this.interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public boolean withdraw(double amount) {
		if (amount >= 0 && amount <= this.balance) {
			this.balance -= amount;
			return true;
		} else {
			return false;
		}
	}

	public boolean deposit(double amount) {
		if (amount >= 0) {
			this.balance += amount;
			return true;
		} else {
			return false;
		}
	}

	public double futureValue(int years) {
		double futureBalanace = this.balance * Math.pow((1 + this.interestRate), years);
		return futureBalanace;
	}

}
