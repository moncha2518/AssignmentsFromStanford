
package com.meritamerica.assignment3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.StringTokenizer;

public class CDAccount extends BankAccount {
	private int term;
	private double balance;
	private Date startDate;
	private Date accountOpenedOn;
	private long accountNumber;
	private double interestRate;
	private double currentBalance;

	private CDOffering offering;

	public CDAccount(CDOffering offering, double balance) {
		super(balance, offering.getInterestRate());
		this.balance = balance;
		this.offering = offering;

	}

	public void setTerm(int term) {
		this.term = term;
	}

	public int getTerm() {
		this.term = this.offering.getTerm();
		return this.term;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Date getStartDate() {
		return startDate;
	}

	public CDOffering getOffering() {
		return offering;
	}

	public void setOffering(CDOffering offering) {
		this.offering = offering;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getOpenedOn() {
		return this.accountOpenedOn;
	}

	public void setOpenedOn() {
		this.accountOpenedOn = accountOpenedOn;
	}

	public long getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber() {
		this.accountNumber = accountNumber;
	}

	public double getInterestRate() {
		return this.interestRate;
	}

	public void setInterestRate() {
		this.interestRate = interestRate;
	}

	public static CDAccount readFromString(String accountData) throws ParseException {
		String st2;
		
		String filePath = ("/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");

		try {
			BufferedReader lineReader = new BufferedReader(new FileReader(filePath));
			String lineText = null;

			while ((lineText = lineReader.readLine()) != null) {
				System.out.println(lineText);
				StringTokenizer st1 = new StringTokenizer(lineText, ","); // 1,0.018
				while (st1.hasMoreTokens()) {
					System.out.println(st1.nextToken());
					st2=st1.nextToken();
					
					
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					
					Date date = sdf.parse(st1.nextToken());
				
				    System.out.println(st1.nextToken());
					
				}
				

			}

			lineReader.close();
		} catch (IOException ex) {
			System.err.println(ex);
		} catch (NumberFormatException e) {
			System.out.println("NumberFormatExcepton is Handled!");
		}

		return null; // has to be fixed
	}

	public boolean withdraw(double amount) {
		if (amount >=0 && amount <=currentBalance) {
			currentBalance -=amount;
			return true;
		} else {
		return false;
		}
	}
	public boolean getMaturity(int term,Date accountOpenedNo) throws Exception {
		int daysInTerm=term*365;
		LocalDate maturityDate=LocalDate.of(2001, 10, daysInTerm);
		Date date1=new SimpleDateFormat("dd/MM/yyyy").parse("10/02/2020");
		System.out.println(date1);
				return true;
	}

	public static double futureValue(double presentValue, double interestRate, int term) {
		double futureBalanace = 0;
		futureBalanace = presentValue * Math.pow(1 + interestRate, term);
		return futureBalanace;
	}

}
