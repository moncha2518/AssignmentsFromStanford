
package com.meritamerica.assignment3;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class CheckingAccount extends BankAccount {
	private double currentBalance = 0;
	private Date accountOpenedOn;
	private long accountNumber;
	private double interestRate;

	public CheckingAccount(double balance, double interestRate) {
		super(balance, interestRate);
	}

	public CheckingAccount(double balance) {
		super(balance);
	}

	public CheckingAccount(long accountNumber, double balance, double interestRate) {
		super(accountNumber, balance, interestRate);
	}

	public Date getOpenedOn() {
		return this.accountOpenedOn;
	}
	public void setOpenedOn() {
		this.accountOpenedOn=accountOpenedOn;
	}
	public long getAccountNumber() {
		return this.accountNumber;
	}
	public void setAccountNumber() {
		this.accountNumber=accountNumber;
	}
	
	public double getInterestRate() {
		return this.interestRate;
	}
	public void setInterestRate() {
		this.interestRate=interestRate;
	}
	
	public static CheckingAccount readFromString(String accountData) throws ParseException {
		String filePath = ("/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");

		try {
			BufferedReader lineReader = new BufferedReader(new FileReader(filePath));
			String lineText = null;
			if (lineReader == null) {
				return null;
			}

			while ((lineText = lineReader.readLine()) != null) {
				System.out.println(lineText);
				StringTokenizer st1 = new StringTokenizer(lineText, ","); // 1,0.018
				while (st1.hasMoreTokens()) {
					System.out.println(st1.nextToken());
				}

			}

			lineReader.close();
		} catch (IOException ex) {
			System.err.println(ex);
		} catch (NumberFormatException e) {
			System.out.println("NumberFormatExcepton is Handled!");
		}

		return null; // has to be fixed

	}

	

	public boolean withdraw(double amount) {
		if (amount >=0 && amount <=currentBalance) {
			currentBalance -=amount;
			return true;
		} else {
		return false;
		}
	}
}
