package com.meritamerica.assignment3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.StringTokenizer;

public class CDOffering {
	
	private int term;
	private double interestRate;
	private String description;

	public CDOffering(int term,double interestRate) {
		this.term=term;
		this.interestRate=interestRate;
	}
	public CDOffering(int term) {
		this.term=term;
	}
	public int getTerm() {
		return this.term;
	}
	public double getInterestRate() {
		return this.interestRate;
	}
	public CDOffering(int term, double interestRate, String description) {
		this.term=term;
		this.interestRate=interestRate;
		this.description=description;
		
	}
	public static CDOffering readFromString(String cdOfferingDataString)  {
		
			String filePath = ("/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			 
			try {
			    BufferedReader lineReader = new BufferedReader(new FileReader(filePath));
			    String lineText = null;
			    if (lineReader == null)
			    {
			    	return null;
			    }
			 
			    while ((lineText = lineReader.readLine()) != null) {
			    		System.out.println(lineText);
			    		StringTokenizer st1 = new StringTokenizer(lineText , ","); //1,0.018
			    		while (st1.hasMoreTokens()) {
			    			System.out.println(st1.nextToken());
			    		}
			       
			    }
			   
			    lineReader.close();
			}  
		 catch (IOException ex) {
			    System.err.println(ex);
			} 
			catch (NumberFormatException e) {
				System.out.println("NumberFormatExcepton is Handled!");
			}
	  
				
	return null; //has to be fixed
		
		}
	
}





