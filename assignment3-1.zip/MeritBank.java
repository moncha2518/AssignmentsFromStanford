package com.meritamerica.assignment3;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.lang.*;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.text.ParseException;

public class MeritBank {
	private static long seedAccountNumber = 1000001; // Initialize the account holder
	private static ArrayList<AccountHolder> accountHolders = new ArrayList<AccountHolder>();
	private static ArrayList<CDOffering> cdOfferings = new ArrayList<CDOffering>();

	public static double accountLimit = 250000.0;

	public static void addAccountHolder(AccountHolder accountHolder) {
		accountHolders.add(accountHolder);
	}

	public static AccountHolder[] getAccountHolders() {
		AccountHolder[] accounts = accountHolders.toArray(new AccountHolder[accountHolders.size()]);
		return accounts;
	}

	public static CDOffering[] getCDOfferings() {
		CDOffering[] accounts = cdOfferings.toArray(new CDOffering[cdOfferings.size()]);
		return accounts;
	}

	public static AccountHolder[] sortAccountHolders() {
		AccountHolder[] accounts = accountHolders.toArray(new AccountHolder[accountHolders.size()]);
		return accounts;
	}
	

	public static CDOffering getBestCDOffering(double depositAmount) {
		System.out.println("cdOfferings.size()=" + cdOfferings.size());
		if (cdOfferings.size() <= 0) {
			return null;
		}
		ArrayList<Double> offerAmounts = new ArrayList<Double>();
		for (int i = 0; i < cdOfferings.size(); i++) {
			offerAmounts.add(depositAmount * cdOfferings.get(i).getInterestRate());
		}
		int bestIndex = getMax(offerAmounts, -1);
		return cdOfferings.get(bestIndex);

	}

	public static CDOffering getSecondBestCDOffering(double depositAmount) {
		System.out.println("cdOfferings.size()=" + cdOfferings.size());

		if (cdOfferings.size() <= 0) {
			return null;
		}
		ArrayList<Double> offerAmounts = new ArrayList<Double>();
		for (int i = 0; i < cdOfferings.size(); i++) {
			offerAmounts.add(depositAmount * cdOfferings.get(i).getInterestRate());
		}
		int bestIndex = getMax(offerAmounts, -1);
		double bestOffer = (double) offerAmounts.get(bestIndex);
		int secondIndex = getMax(offerAmounts, bestOffer);

		return cdOfferings.get(secondIndex);
	}

	// Method for getting the max value and place of value
	public static int getMax(ArrayList<Double> valueList, double valueCompare) {
		double maxValue = valueList.get(0);
		int maxIndex = 0;
		for (int i = 1; i < valueList.size(); i++) {
			boolean isMax = false;
			double value = valueList.get(i);
			if (valueCompare < 0) {
				isMax = value > maxValue;
			} else {
				isMax = (value > maxValue) && (value < valueCompare);
			}

			if (isMax) {
				maxValue = value;
				maxIndex = i;
			}
		}

		return maxIndex;
	}

	public static void clearCDOfferings() {
		cdOfferings.clear();

		ArrayList<CDOffering> cdOfferings = new ArrayList<CDOffering>();

	}

	public static void setCDOfferings(CDOffering[] offerings) {

		for (CDOffering offering : offerings)
			cdOfferings.add(offering);
	}

	public static long getNextAccountNumber() {
		seedAccountNumber += 1;
		return seedAccountNumber;
	}
	public static void setNextAccountNumber(long nextAccountNumber) {
		nextAccountNumber=nextAccountNumber;
	}

	// get a total balance from a whole bank
	public static double totalBalances() {
		double totalBalances = 0;
		for (AccountHolder accountHolder : accountHolders) {
			totalBalances += accountHolder.getCombinedBalance();
		}
		return totalBalances;
	}

//--------------------------To read a data from text file----------------------
	public static boolean readFromFile(String fileName) {

		try {
		//Scanner file=new Scanner (new File ("dataFile.txt");
			fileName=("/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");;
		//	File myObject = new File("/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			File myObject = new File(fileName);
			Scanner myReader = new Scanner(myObject);
			if (myObject.exists()) {
			   
				while (myReader.hasNext()) {

					String data = myReader.nextLine();
					System.out.println(data);
				}
				
				myReader.close();
			} else {
			
				return false;
			}
		} catch(FileNotFoundException e) {
			System.out.println("File Not Found Exception get caught!");
		}
		catch(IOException ioe) {
		
			ioe.printStackTrace();

		}
		
		
	 
		return true;
			
	}
//-------------------------- End to read a data from text file----------------------	

//--------------------------To create & write to a new file -------------------------------
	public static boolean writeToFile(String fileName) throws IOException {
		try {
			File myObject = new File(
					"/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			if (myObject.createNewFile()) {
				System.out.println("File created: " + myObject.getName());
			} else {
				System.out.println("File already exists.");
			}
			FileWriter myWriter = new FileWriter(
					"/Users/user/eclipse-workspaceStanford/ProjectStanford/assignment3-1/src/test/testMeritBank_good.txt");
			myWriter.write("Files in Java might be tricky, but it is fun enough!");
			myWriter.close();
			System.out.println("Successfully wrote to the file.");

		} catch (IOException e) {
			System.out.println("IOException got caught");
			e.printStackTrace();
			return false;
		}
		return true;

	}
//--------------------------End To create & write to a new file----------------------------

	public static double futureValue(double presentValue, double interestRate, int term) {
		double futureBalanace = 0;
		futureBalanace = presentValue * Math.pow(1 + interestRate, term);
		return futureBalanace;
	}
}
